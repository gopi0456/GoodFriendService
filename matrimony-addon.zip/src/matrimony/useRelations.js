import { useCallback, useEffect, useState } from 'react'
import { supabase } from '../supabaseClient'

// Loads my sent/received interests and shortlist in one place
export default function useRelations(userId) {
  const [sentList, setSentList] = useState([])
  const [receivedList, setReceivedList] = useState([])
  const [shortlist, setShortlist] = useState(new Set())

  const reload = useCallback(async () => {
    const [a, b, c] = await Promise.all([
      supabase.from('matrimony_interests').select('*').eq('from_user', userId).order('created_at', { ascending: false }),
      supabase.from('matrimony_interests').select('*').eq('to_user', userId).order('created_at', { ascending: false }),
      supabase.from('matrimony_shortlist').select('profile_id').eq('user_id', userId),
    ])
    setSentList(a.data || [])
    setReceivedList(b.data || [])
    setShortlist(new Set((c.data || []).map(r => r.profile_id)))
  }, [userId])

  useEffect(() => { reload() }, [reload])

  const sent = {}
  sentList.forEach(i => { sent[i.to_user] = i.status })
  const received = {}
  receivedList.forEach(i => { received[i.from_user] = i.status })

  return { sentList, receivedList, sent, received, shortlist, reload }
}
