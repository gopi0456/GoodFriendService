import { useCallback, useEffect, useState } from 'react'
import { supabase } from '../supabaseClient'
import { calcAge, heightLabel, maritalLabel } from './utils'
import { Avatar } from './ProfileView'

export default function AdminReview() {
  const [status, setStatus] = useState('pending')
  const [items, setItems] = useState([])
  const [loading, setLoading] = useState(true)

  const load = useCallback(async () => {
    setLoading(true)
    const { data, error } = await supabase.from('matrimony_profiles').select('*')
      .eq('status', status).order('created_at', { ascending: false })
    if (error) alert('Error: ' + error.message)
    setItems(data || [])
    setLoading(false)
  }, [status])

  useEffect(() => { load() }, [load])

  const setProfileStatus = async (id, next) => {
    const { error } = await supabase.from('matrimony_profiles').update({ status: next }).eq('user_id', id)
    if (error) return alert('Error: ' + error.message)
    load()
  }

  return (
    <div>
      <div className="mm-subtabs">
        {['pending', 'approved', 'rejected'].map(s => (
          <div key={s} className={`mm-subtab ${status === s ? 'active' : ''}`} onClick={() => setStatus(s)}>{s}</div>
        ))}
      </div>
      {loading && <div className="mm-empty">Loading...</div>}
      {!loading && items.length === 0 && <div className="mm-empty">Nothing here.</div>}
      {items.map(p => (
        <div className="card mm-card" key={p.user_id} style={{ cursor: 'default' }}>
          <Avatar profile={p} />
          <div className="mm-card-body">
            <div className="text-bold">{p.full_name}, {calcAge(p.dob)} ({p.gender})</div>
            <div className="text-sm">{[heightLabel(p.height_cm), maritalLabel(p.marital_status), p.religion].filter(Boolean).join(' • ')}</div>
            <div className="text-sm">{[p.education, p.occupation, p.city].filter(Boolean).join(' • ')}</div>
            {p.about && <div className="text-sm">{p.about}</div>}
            <div style={{ display: 'flex', gap: 8, marginTop: 8 }}>
              {status !== 'approved' && <button className="btn btn-sm btn-success" onClick={() => setProfileStatus(p.user_id, 'approved')}>Approve</button>}
              {status !== 'rejected' && <button className="btn btn-sm btn-danger" onClick={() => setProfileStatus(p.user_id, 'rejected')}>Reject</button>}
            </div>
          </div>
        </div>
      ))}
    </div>
  )
}
