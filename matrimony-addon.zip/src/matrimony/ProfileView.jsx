import { useEffect, useState } from 'react'
import { supabase } from '../supabaseClient'
import { calcAge, heightLabel, maritalLabel, photoUrl, respondInterest } from './utils'

export function Avatar({ profile, size = 64 }) {
  const url = photoUrl(profile.photo_path)
  if (url) return <img className="mm-avatar" style={{ width: size, height: size }} src={url} alt="" loading="lazy" />
  return (
    <div className="mm-avatar mm-avatar-ph" style={{ width: size, height: size, fontSize: size / 2 }}>
      {profile.gender === 'female' ? '👩' : '👨'}
    </div>
  )
}

export function ProfileCard({ profile, onOpen, footer }) {
  return (
    <div className="card mm-card" onClick={onOpen}>
      <Avatar profile={profile} />
      <div className="mm-card-body">
        <div className="text-bold">{profile.full_name}, {calcAge(profile.dob)}</div>
        <div className="text-sm">{[heightLabel(profile.height_cm), profile.religion].filter(Boolean).join(' • ')}</div>
        <div className="text-sm">{[profile.occupation, profile.city].filter(Boolean).join(' • ')}</div>
        {footer}
      </div>
    </div>
  )
}

const Row = ({ label, value }) => (value ? (
  <div className="detail-row"><span className="label">{label}</span><span className="value">{value}</span></div>
) : null)

export default function ProfileView({ profile, userId, rel, onClose }) {
  const [busy, setBusy] = useState(false)
  const [phone, setPhone] = useState(null)
  const id = profile.user_id
  const sentStatus = rel.sent[id]
  const recvStatus = rel.received[id]
  const accepted = sentStatus === 'accepted' || recvStatus === 'accepted'
  const saved = rel.shortlist.has(id)
  const url = photoUrl(profile.photo_path)

  useEffect(() => {
    if (!accepted) { setPhone(null); return }
    let alive = true
    supabase.from('matrimony_contacts').select('phone').eq('user_id', id).maybeSingle()
      .then(({ data }) => { if (alive) setPhone(data?.phone || '') })
    return () => { alive = false }
  }, [accepted, id])

  const run = async (fn) => {
    setBusy(true)
    try {
      const { error } = await fn()
      if (error && error.code !== '23505') alert('Error: ' + error.message)
      await rel.reload()
    } finally { setBusy(false) }
  }

  const sendInterest = () => run(() => supabase.from('matrimony_interests').insert({ from_user: userId, to_user: id }))
  const withdraw = () => run(() => supabase.from('matrimony_interests').delete().eq('from_user', userId).eq('to_user', id))
  const respond = (status) => run(() => respondInterest(id, userId, status))
  const toggleSave = () => run(() => saved
    ? supabase.from('matrimony_shortlist').delete().eq('user_id', userId).eq('profile_id', id)
    : supabase.from('matrimony_shortlist').insert({ user_id: userId, profile_id: id }))

  let action = null
  if (recvStatus === 'pending') {
    action = (
      <div className="mm-row">
        <button className="btn btn-success" disabled={busy} onClick={() => respond('accepted')}>✅ Accept</button>
        <button className="btn btn-danger" disabled={busy} onClick={() => respond('declined')}>✖ Decline</button>
      </div>
    )
  } else if (sentStatus === 'pending') {
    action = <button className="btn mm-btn-light" disabled={busy} onClick={withdraw}>⏳ Interest sent - tap to withdraw</button>
  } else if (sentStatus === 'declined' || recvStatus === 'declined') {
    action = <div className="mm-banner bad">This interest was declined.</div>
  } else if (accepted) {
    action = (
      <div className="mm-banner ok">
        🎉 Interest accepted.<br />
        {phone === null ? 'Loading contact...' : phone ? <>Phone: <b>{phone}</b></> : 'No phone number shared.'}
      </div>
    )
  } else {
    action = <button className="btn mm-btn-pink" disabled={busy} onClick={sendInterest}>💌 Send Interest</button>
  }

  return (
    <div className="modal-overlay" onClick={onClose}>
      <div className="modal" onClick={e => e.stopPropagation()}>
        {url ? <img className="mm-photo-big" src={url} alt="" /> : <div className="mm-photo-ph">{profile.gender === 'female' ? '👩' : '👨'}</div>}
        <h3>{profile.full_name}, {calcAge(profile.dob)}</h3>

        <div className="ride-details">
          <Row label="Height" value={heightLabel(profile.height_cm)} />
          <Row label="Marital status" value={maritalLabel(profile.marital_status)} />
          <Row label="Religion" value={profile.religion} />
          <Row label="Caste" value={profile.caste} />
          <Row label="Mother tongue" value={profile.mother_tongue} />
          <Row label="Education" value={profile.education} />
          <Row label="Occupation" value={profile.occupation} />
          <Row label="Income" value={profile.annual_income} />
          <Row label="Location" value={[profile.city, profile.state].filter(Boolean).join(', ')} />
        </div>

        {profile.about && (<><div className="mm-section-title">About</div><p className="text-sm">{profile.about}</p></>)}
        {profile.partner_expectations && (<><div className="mm-section-title">Looking for</div><p className="text-sm">{profile.partner_expectations}</p></>)}

        <div style={{ marginTop: 14 }}>{action}</div>
        <div className="modal-actions">
          <button className="btn mm-btn-light" disabled={busy} onClick={toggleSave}>{saved ? '★ Saved' : '☆ Save'}</button>
          <button className="btn mm-btn-light" onClick={onClose}>Close</button>
        </div>
      </div>
    </div>
  )
}
