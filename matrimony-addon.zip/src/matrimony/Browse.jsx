import { useCallback, useEffect, useState } from 'react'
import { supabase } from '../supabaseClient'
import { MARITAL, RELIGIONS, yearsAgo } from './utils'
import ProfileView, { ProfileCard } from './ProfileView'

const PAGE = 15

export default function Browse({ userId, me, rel }) {
  const [filters, setFilters] = useState({
    gender: me.gender === 'male' ? 'female' : 'male',
    ageMin: 21, ageMax: 40, religion: '', marital: '', city: '', caste: '',
  })
  const [showFilters, setShowFilters] = useState(false)
  const [items, setItems] = useState([])
  const [loading, setLoading] = useState(false)
  const [more, setMore] = useState(false)
  const [open, setOpen] = useState(null)

  const load = useCallback(async (reset, f) => {
    setLoading(true)
    const from = reset ? 0 : items.length
    let q = supabase.from('matrimony_profiles').select('*')
      .eq('status', 'approved').neq('user_id', userId).eq('gender', f.gender)
      .lte('dob', yearsAgo(Number(f.ageMin) || 18))
      .gte('dob', yearsAgo((Number(f.ageMax) || 80) + 1, true))
    if (f.religion) q = q.eq('religion', f.religion)
    if (f.marital) q = q.eq('marital_status', f.marital)
    if (f.city.trim()) q = q.ilike('city', `%${f.city.trim()}%`)
    if (f.caste.trim()) q = q.ilike('caste', `%${f.caste.trim()}%`)
    const { data, error } = await q.order('created_at', { ascending: false }).range(from, from + PAGE - 1)
    if (error) alert('Error: ' + error.message)
    const rows = data || []
    setItems(prev => (reset ? rows : [...prev, ...rows]))
    setMore(rows.length === PAGE)
    setLoading(false)
  }, [userId, items.length])

  useEffect(() => { load(true, filters) }, []) // first load only

  const set = (k) => (e) => setFilters(f => ({ ...f, [k]: e.target.value }))
  const apply = () => { setShowFilters(false); load(true, filters) }

  return (
    <div>
      <button className="btn mm-btn-light" style={{ marginTop: 0 }} onClick={() => setShowFilters(s => !s)}>
        🔍 Filters {showFilters ? '▲' : '▼'}
      </button>

      {showFilters && (
        <div className="card" style={{ marginTop: 10 }}>
          <div className="mm-row">
            <div className="input-group"><label>Show</label>
              <select className="input mm-select" value={filters.gender} onChange={set('gender')}>
                <option value="female">Brides</option><option value="male">Grooms</option>
              </select>
            </div>
            <div className="input-group"><label>Marital status</label>
              <select className="input mm-select" value={filters.marital} onChange={set('marital')}>
                <option value="">Any</option>{MARITAL.map(([v, l]) => <option key={v} value={v}>{l}</option>)}
              </select>
            </div>
          </div>
          <div className="mm-row">
            <div className="input-group"><label>Age from</label>
              <input className="input" type="number" inputMode="numeric" value={filters.ageMin} onChange={set('ageMin')} /></div>
            <div className="input-group"><label>Age to</label>
              <input className="input" type="number" inputMode="numeric" value={filters.ageMax} onChange={set('ageMax')} /></div>
          </div>
          <div className="input-group"><label>Religion</label>
            <select className="input mm-select" value={filters.religion} onChange={set('religion')}>
              <option value="">Any</option>{RELIGIONS.map(r => <option key={r}>{r}</option>)}
            </select>
          </div>
          <div className="mm-row">
            <div className="input-group"><label>City</label><input className="input" value={filters.city} onChange={set('city')} /></div>
            <div className="input-group"><label>Caste</label><input className="input" value={filters.caste} onChange={set('caste')} /></div>
          </div>
          <button className="btn mm-btn-pink" onClick={apply}>Apply filters</button>
        </div>
      )}

      <div style={{ marginTop: 14 }}>
        {items.map(p => (
          <ProfileCard key={p.user_id} profile={p} onOpen={() => setOpen(p)}
            footer={rel.sent[p.user_id] || rel.received[p.user_id]
              ? <span className={`badge badge-${rel.sent[p.user_id] || rel.received[p.user_id]}`}>{rel.sent[p.user_id] || rel.received[p.user_id]}</span>
              : null} />
        ))}
        {!loading && items.length === 0 && <div className="mm-empty">No profiles match these filters yet.</div>}
        {loading && <div className="mm-empty">Loading...</div>}
        {more && !loading && <button className="btn mm-btn-light" onClick={() => load(false, filters)}>Load more</button>}
      </div>

      {open && <ProfileView profile={open} userId={userId} rel={rel} onClose={() => setOpen(null)} />}
    </div>
  )
}
