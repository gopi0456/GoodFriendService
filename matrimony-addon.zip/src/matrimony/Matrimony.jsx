import { useEffect, useState } from 'react'
import { supabase, adminEmail } from '../supabaseClient'
import './matrimony.css'
import useRelations from './useRelations'
import MyProfile from './MyProfile'
import Browse from './Browse'
import Interests from './Interests'
import Shortlist from './Shortlist'
import AdminReview from './AdminReview'

export default function Matrimony({ session, onBack }) {
  const userId = session.user.id
  const isAdmin = session.user.email === adminEmail
  const [tab, setTab] = useState('browse')
  const [me, setMe] = useState(undefined) // undefined = loading, null = no profile yet
  const [loadError, setLoadError] = useState('')
  const rel = useRelations(userId)

  const loadMe = async () => {
    const { data, error } = await supabase.from('matrimony_profiles').select('*').eq('user_id', userId).maybeSingle()
    if (error) {
      setLoadError(error.message)
      setMe(null)
      return
    }
    setLoadError('')
    setMe(data)
  }

  useEffect(() => { loadMe() }, [userId])
  useEffect(() => { if (me === null) setTab('profile') }, [me])

  const shell = (body) => (
    <div>
      <div className="header mm-header">
        <button className="back-btn" onClick={onBack}>← Back</button>
        <div className="header-title">💍 Matrimonial</div>
        <div style={{ width: 70 }} />
      </div>
      {body}
    </div>
  )

  if (me === undefined) return shell(<div className="content mm-empty">Loading...</div>)

  const approved = me?.status === 'approved'
  const pendingIn = rel.receivedList.filter(i => i.status === 'pending').length
  const tabs = me
    ? [['browse', '🔍 Browse'], ['interests', `💌 Interests${pendingIn ? ` (${pendingIn})` : ''}`], ['saved', '⭐ Saved'], ['profile', '👤 Mine']]
    : [['profile', '👤 My Profile']]
  if (isAdmin) tabs.push(['admin', '⚙️ Admin'])

  let banner = null
  if (loadError) {
    banner = <div className="mm-banner bad">Could not load matrimony data: {loadError}. Make sure <b>matrimony.sql</b> was run in Supabase.</div>
  } else if (!me) {
    banner = <div className="mm-banner warn">Create your profile to start. It will be visible to others after admin approval.</div>
  } else if (me.status === 'pending') {
    banner = <div className="mm-banner warn">⏳ Your profile is waiting for approval. You can browse after it is approved.</div>
  } else if (me.status === 'rejected') {
    banner = <div className="mm-banner bad">Your profile was not approved. Please update it and contact the admin.</div>
  }

  let body
  if (tab === 'profile') body = <MyProfile userId={userId} me={me} onSaved={loadMe} />
  else if (tab === 'admin' && isAdmin) body = <AdminReview />
  else if (!approved) body = <div className="mm-empty">Available once your profile is approved.</div>
  else if (tab === 'browse') body = <Browse userId={userId} me={me} rel={rel} />
  else if (tab === 'interests') body = <Interests userId={userId} rel={rel} />
  else body = <Shortlist userId={userId} rel={rel} />

  return shell(
    <>
      <div className="tabs mm-tabs">
        {tabs.map(([k, label]) => (
          <div key={k} className={`tab ${tab === k ? 'active' : ''}`} onClick={() => setTab(k)}>{label}</div>
        ))}
      </div>
      <div className="content">
        {banner}
        {body}
      </div>
    </>
  )
}
