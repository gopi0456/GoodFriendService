import { useEffect, useState } from 'react'
import { supabase } from '../supabaseClient'
import { BUCKET, EDUCATION, INCOME, LANGUAGES, MARITAL, RELIGIONS, calcAge, photoUrl, resizeImage } from './utils'

const Field = ({ label, children }) => (
  <div className="input-group"><label>{label}</label>{children}</div>
)

const EMPTY = {
  full_name: '', gender: '', dob: '', height_cm: '', marital_status: 'never_married',
  religion: '', caste: '', mother_tongue: '', education: '', occupation: '', annual_income: '',
  city: '', state: '', about: '', partner_expectations: '', photo_path: '', phone: '',
}

export default function MyProfile({ userId, me, onSaved }) {
  const [form, setForm] = useState(EMPTY)
  const [saving, setSaving] = useState(false)
  const [uploading, setUploading] = useState(false)

  useEffect(() => {
    if (!me) return
    setForm(f => ({ ...f, ...Object.fromEntries(Object.entries(me).map(([k, v]) => [k, v ?? ''])) }))
    supabase.from('matrimony_contacts').select('phone').eq('user_id', userId).maybeSingle()
      .then(({ data }) => { if (data) setForm(f => ({ ...f, phone: data.phone })) })
  }, [me, userId])

  const set = (k) => (e) => setForm(f => ({ ...f, [k]: e.target.value }))

  const pickPhoto = async (e) => {
    const file = e.target.files?.[0]
    if (!file) return
    setUploading(true)
    try {
      const blob = await resizeImage(file)
      const path = `${userId}/${Date.now()}.jpg`
      const { error } = await supabase.storage.from(BUCKET).upload(path, blob, { contentType: 'image/jpeg' })
      if (error) throw error
      setForm(f => ({ ...f, photo_path: path }))
    } catch (err) {
      alert('Photo upload failed: ' + err.message)
    } finally { setUploading(false); e.target.value = '' }
  }

  const save = async (e) => {
    e.preventDefault()
    if (!form.full_name.trim()) return alert('Please enter your name')
    if (!form.gender) return alert('Please select gender')
    if (!form.dob) return alert('Please enter date of birth')
    if (calcAge(form.dob) < 18) return alert('You must be at least 18 years old')
    if (!/^[0-9+\-\s]{10,15}$/.test(form.phone.trim())) return alert('Enter a valid phone number')
    const h = form.height_cm ? Number(form.height_cm) : null
    if (h && (h < 100 || h > 250)) return alert('Height must be between 100 and 250 cm')

    setSaving(true)
    try {
      const payload = {
        user_id: userId,
        full_name: form.full_name.trim(),
        gender: form.gender,
        dob: form.dob,
        height_cm: h,
        marital_status: form.marital_status,
        religion: form.religion || null,
        caste: form.caste.trim() || null,
        mother_tongue: form.mother_tongue || null,
        education: form.education || null,
        occupation: form.occupation.trim() || null,
        annual_income: form.annual_income || null,
        city: form.city.trim() || null,
        state: form.state.trim() || null,
        about: form.about.trim() || null,
        partner_expectations: form.partner_expectations.trim() || null,
        photo_path: form.photo_path || null,
      }
      const a = await supabase.from('matrimony_profiles').upsert(payload, { onConflict: 'user_id' })
      if (a.error) throw a.error
      const b = await supabase.from('matrimony_contacts').upsert({ user_id: userId, phone: form.phone.trim() }, { onConflict: 'user_id' })
      if (b.error) throw b.error
      if (me?.photo_path && me.photo_path !== form.photo_path) {
        supabase.storage.from(BUCKET).remove([me.photo_path]) // best effort cleanup
      }
      alert(me ? '✅ Profile updated' : '✅ Profile submitted for approval')
      onSaved()
    } catch (err) {
      alert('Error: ' + err.message)
    } finally { setSaving(false) }
  }

  const url = photoUrl(form.photo_path)

  return (
    <form onSubmit={save}>
      <div style={{ textAlign: 'center', marginBottom: 14 }}>
        {url
          ? <img className="mm-avatar" style={{ width: 110, height: 110 }} src={url} alt="" />
          : <div className="mm-avatar mm-avatar-ph" style={{ width: 110, height: 110, fontSize: 52, margin: '0 auto' }}>{form.gender === 'female' ? '👩' : '👨'}</div>}
        <div style={{ marginTop: 8 }}>
          <label className="btn btn-sm mm-btn-light" style={{ cursor: 'pointer' }}>
            {uploading ? 'Uploading...' : '📷 Choose photo'}
            <input type="file" accept="image/*" onChange={pickPhoto} disabled={uploading} style={{ display: 'none' }} />
          </label>
        </div>
      </div>

      <div className="mm-section-title">Basic</div>
      <Field label="Full name *"><input className="input" value={form.full_name} onChange={set('full_name')} /></Field>
      <div className="mm-row">
        <Field label="Gender *">
          <select className="input mm-select" value={form.gender} onChange={set('gender')}>
            <option value="">Select</option><option value="male">Male</option><option value="female">Female</option>
          </select>
        </Field>
        <Field label="Date of birth *"><input className="input" type="date" value={form.dob} onChange={set('dob')} /></Field>
      </div>
      <div className="mm-row">
        <Field label="Height (cm)"><input className="input" type="number" inputMode="numeric" value={form.height_cm} onChange={set('height_cm')} /></Field>
        <Field label="Marital status">
          <select className="input mm-select" value={form.marital_status} onChange={set('marital_status')}>
            {MARITAL.map(([v, l]) => <option key={v} value={v}>{l}</option>)}
          </select>
        </Field>
      </div>
      <Field label="Phone * (shown only after an interest is accepted)">
        <input className="input" type="tel" value={form.phone} onChange={set('phone')} />
      </Field>

      <div className="mm-section-title">Background</div>
      <div className="mm-row">
        <Field label="Religion">
          <select className="input mm-select" value={form.religion} onChange={set('religion')}>
            <option value="">Select</option>{RELIGIONS.map(r => <option key={r}>{r}</option>)}
          </select>
        </Field>
        <Field label="Caste"><input className="input" value={form.caste} onChange={set('caste')} /></Field>
      </div>
      <Field label="Mother tongue">
        <select className="input mm-select" value={form.mother_tongue} onChange={set('mother_tongue')}>
          <option value="">Select</option>{LANGUAGES.map(r => <option key={r}>{r}</option>)}
        </select>
      </Field>

      <div className="mm-section-title">Education & work</div>
      <div className="mm-row">
        <Field label="Education">
          <select className="input mm-select" value={form.education} onChange={set('education')}>
            <option value="">Select</option>{EDUCATION.map(r => <option key={r}>{r}</option>)}
          </select>
        </Field>
        <Field label="Annual income">
          <select className="input mm-select" value={form.annual_income} onChange={set('annual_income')}>
            <option value="">Select</option>{INCOME.map(r => <option key={r}>{r}</option>)}
          </select>
        </Field>
      </div>
      <Field label="Occupation"><input className="input" value={form.occupation} onChange={set('occupation')} /></Field>

      <div className="mm-section-title">Location</div>
      <div className="mm-row">
        <Field label="City"><input className="input" value={form.city} onChange={set('city')} /></Field>
        <Field label="State"><input className="input" value={form.state} onChange={set('state')} /></Field>
      </div>

      <div className="mm-section-title">About you</div>
      <Field label="About me"><textarea className="input mm-textarea" maxLength={600} value={form.about} onChange={set('about')} /></Field>
      <Field label="What I'm looking for"><textarea className="input mm-textarea" maxLength={600} value={form.partner_expectations} onChange={set('partner_expectations')} /></Field>

      <button className="btn mm-btn-pink" type="submit" disabled={saving || uploading}>
        {saving ? 'Saving...' : me ? '💾 Update Profile' : '📨 Submit Profile'}
      </button>
    </form>
  )
}
