import { useEffect, useState } from 'react'
import { supabase } from '../supabaseClient'
import { respondInterest } from './utils'
import ProfileView, { ProfileCard } from './ProfileView'

export default function Interests({ userId, rel }) {
  const [sub, setSub] = useState('received')
  const [profiles, setProfiles] = useState({})
  const [open, setOpen] = useState(null)

  const list = sub === 'received' ? rel.receivedList : rel.sentList
  const otherId = (i) => (sub === 'received' ? i.from_user : i.to_user)

  useEffect(() => {
    const ids = [...new Set(list.map(otherId))].filter(id => !profiles[id])
    if (!ids.length) return
    supabase.from('matrimony_profiles').select('*').in('user_id', ids).then(({ data }) => {
      const map = {}
      ;(data || []).forEach(p => { map[p.user_id] = p })
      setProfiles(prev => ({ ...prev, ...map }))
    })
  }, [list])

  const answer = async (e, i, status) => {
    e.stopPropagation()
    const { error } = await respondInterest(i.from_user, userId, status)
    if (error) alert('Error: ' + error.message)
    rel.reload()
  }

  const rows = list.filter(i => profiles[otherId(i)])

  return (
    <div>
      <div className="mm-subtabs">
        <div className={`mm-subtab ${sub === 'received' ? 'active' : ''}`} onClick={() => setSub('received')}>Received</div>
        <div className={`mm-subtab ${sub === 'sent' ? 'active' : ''}`} onClick={() => setSub('sent')}>Sent</div>
      </div>

      {rows.map(i => {
        const p = profiles[otherId(i)]
        return (
          <ProfileCard key={i.id} profile={p} onOpen={() => setOpen(p)}
            footer={
              <div style={{ marginTop: 6 }}>
                <span className={`badge badge-${i.status === 'declined' ? 'rejected' : i.status}`}>{i.status}</span>
                {sub === 'received' && i.status === 'pending' && (
                  <div style={{ marginTop: 8, display: 'flex', gap: 8 }}>
                    <button className="btn btn-sm btn-success" onClick={(e) => answer(e, i, 'accepted')}>Accept</button>
                    <button className="btn btn-sm btn-danger" onClick={(e) => answer(e, i, 'declined')}>Decline</button>
                  </div>
                )}
              </div>
            } />
        )
      })}
      {list.length === 0 && <div className="mm-empty">{sub === 'received' ? 'No interests received yet.' : 'You have not sent any interests yet.'}</div>}

      {open && <ProfileView profile={open} userId={userId} rel={rel} onClose={() => setOpen(null)} />}
    </div>
  )
}
